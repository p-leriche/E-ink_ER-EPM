/***************************************************
//Web: http://www.buydisplay.com
EastRising Technology Co.,LTD
****************************************************/

extern const unsigned char IMAGE_BLACK[];
extern const unsigned char IMAGE_BLACK1[];
extern const unsigned char IMAGE_RED[];
extern const unsigned char IMAGE_RED1[];

/* FILE END */


